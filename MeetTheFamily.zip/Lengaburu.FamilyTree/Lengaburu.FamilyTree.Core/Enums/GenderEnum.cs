﻿namespace Lengaburu.FamilyTree.Core.Enums
{
    public class GenderEnum
    {
        public enum Gender
        {
            Male,
            Female
        }
    }
}