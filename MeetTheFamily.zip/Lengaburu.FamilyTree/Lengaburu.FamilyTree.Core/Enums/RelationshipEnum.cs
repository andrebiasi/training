﻿namespace Lengaburu.FamilyTree.Core.Enums
{
    public class RelationshipEnum
    {
        public enum RelationshipType
        { 
            Parent,
            Spouse,
            Child,
            Sibling
        }
    }
}