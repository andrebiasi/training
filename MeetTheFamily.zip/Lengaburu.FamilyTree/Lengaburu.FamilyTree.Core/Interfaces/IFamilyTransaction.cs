﻿namespace Lengaburu.FamilyTree.Core.Interfaces
{
    public interface IFamilyTransaction
    {
        string Execute();
    }
}