# Letter to Candidate

Hi [Candidate Name],

Great to speak with you.

As discussed, the next step in our process is for you to complete a coding challenge. We're using a website called HackerRank to host the challenge. Please click on the invitation link below to access the challenge.

[Paste Invite Link To Challenge Here]

We know you're busy, have commitments, and are applying for other roles. Your time is valuable. The challenge should take less than 3 hours and we ask that you return it by [Return Date for Challenge].

To help you with your application you can read some information about us:

* Our website: https://www.myob.com/au
* The MYOB Way video: https://youtu.be/jEI3wU89VXo
* Our careers site: https://www.myob.com/au/careers

We love to share knowledge and improve people. We do this through the way we work, and also through sponsoring events such as:

* Random Hacks of Kindness (RHOK): https://www.rhokaustralia.org/melbourne
* DevelopHER program: https://www.myob.com/au/careers/myob-developher-program
* YOW! Conference: https://yowconference.com/melbourne/

Our culture is amazing! We are a team of genuine and passionate technologists. Leaders are available to anyone at any time... Greg, our CEO, even sits on the floor amongst the team.

Above all else, we want to see you succeed. We support curious minds, have diverse technical environments, and your career development is important to us. Helping people grow and succeed in their careers is our passion.

Please let me know if you have any questions.

Enjoy your week.

Cheers,

[Talent Team Member Name]
