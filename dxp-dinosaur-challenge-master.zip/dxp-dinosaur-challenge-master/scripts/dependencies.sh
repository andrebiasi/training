#!/usr/bin/env bash

set -o errexit
set -o pipefail
set -o nounset

# Here will be what we need to do to set up dependencies in HackerRank.

apt-get update
apt-get -y upgrade
