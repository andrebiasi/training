#!/usr/bin/env bash

set -o errexit
set -o pipefail
set -o nounset

mkdir -p test
echo -e "TAP version 13\n1..1\n#\n# HackerRank test results\n#\nok 1 - HackerRank is happy" > test/result.txt

# Please enter the commands required to test your solution below this line.
