const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const randomNumber = require('random-number');

const PORT = 1337;

const app = express();

app.use(bodyParser.json());
app.use(cors());

app.put('/api/settings', (req, res) => {
  const number_of_eggs = req.body.number_of_eggs;
  const rotation_amount = req.body.rotation_amount;
  const sequence = req.body.sequence;

  if (!number_of_eggs || !rotation_amount || !sequence) {
    res.status(400).json({
      status: 'ERROR',
      reason: 'The required information was not provided'
    });
  } else {
    res.json({
      status: 'OK'
    });
  }
});

app.post('/api/run', (req, res) => {
  const report = {
    number_of_eggs: randomNumber({ min: 1, max: 20, integer: true }),
    sequence: '',
    rotation_amount: randomNumber({ min: 0, max: 1, integer: false }),
    rotations: []
  }

  for (let i = 1; i <= report.number_of_eggs; i++) {
    report.rotations.push({ egg: i, was_rotated: randomNumber({ min: 0, max: 5, integer: false }) });
  }

  const sequence_parts = [];

  for (let j = 0; j < 25; j++) {
    sequence_parts.push(randomNumber({ min: 1, max: report.number_of_eggs, integer: true }));
  }

  report.sequence = sequence_parts.join(' ');

  res.json({ report: report });
});

app.listen(PORT, () => {
  console.log(`REST API listening on http://localhost:${PORT}`);
});
