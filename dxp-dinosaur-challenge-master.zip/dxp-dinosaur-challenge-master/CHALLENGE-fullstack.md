# Dinosaur Egg Incubator Full-Stack Challenge

The owners of Triassic Island have purchased a new incubator which is used to help the dinosaur eggs mature and hatch. The incubator has a device which turns the eggs. The eggs are required to turned to ensure that they develop correctly. However the incubator did not include the application to run the device which turns the eggs (it is a pre-release model). Your task is to write that application.

![Incubator](assets/incubator.jpg)

The incubator can hold up to 20 eggs at one time, and it holds the eggs in a single line. The device in the incubator will turn the eggs by the sequence provided to it.

The incubator has two modes of operation. First mode is "settings" where the parameters for turning the eggs are defined. The second mode is "run" which runs the sequence and reports on the actions which were taken by the device.

The application will be a web application which has a front-end which communicates with a back-end web API service.

The back-end web API REST service will have the following routes:

* PUT `/api/settings` - used for updating the settings
* POST `/api/run` - used for running the program based on the settings provided and report the results

The `/api/settings` route takes the following inputs:

* Number of eggs - The number of eggs loaded into the incubator. You can assume that the eggs are all in a row with no gaps in between the eggs. This is a number between 0 and 20.
* Rotation amount - How much the egg should be rotated when the device is told to turn the egg. This will be a percentage (25 means a quarter of a rotation, 75 means three quarters of a rotation). The rotation amount is the same for all the eggs.
* Sequence - The order which the eggs will be rotated. An egg can be rotated more than once. The sequence is a whitespace separated list of numbers. An example would be `1 3 5 2 4 4 2 1 3 4`.

The `/api/settings` response will be an indication whether the settings were accepted or not.

The `/api/run` route does not take any inputs.

The `/api/run` response will be a report of the settings and the rotations of each of the eggs. An example JSON response could look like the following:

```
{
	"report": {
		"number_of_eggs": 5,
	    "sequence": "1 3 5 2 4 4 2 1 3 4",
	    "rotation_amount": 0.25,
		"rotations": [
			{ "egg": 1, "was_rotated": 0.5 },
			{ "egg": 2, "was_rotated": 0.5 },
			{ "egg": 3, "was_rotated": 0.5 },
			{ "egg": 4, "was_rotated": 0.75 },
			{ "egg": 5, "was_rotated": 0.25 }
		]
	}
}
```

The front-end web application will have 3 screens:

![Screen 1](assets/screen-1-fullstack.jpg)

Settings screen which has inputs for "Number of eggs", "Rotation amount", and "Sequence".

![Screen 2](assets/screen-2-fullstack.jpg)

After the settings have been submitted and accepted a screen with a "Run" button should be shown to the user.

![Screen 3](assets/screen-3-fullstack.jpg)

After the run command has been submitted, the front-end should display the report in an easy to understand way.

## Considerations

You should take into account the following:

* The device cannot rotate an egg which is not in the machine. If the sequence refers to an egg which is not loaded in the machine then that rotation should be skipped or ignored.
* The most that the device can rotate an egg at one time is one full rotation.
* There is no limit to the length of the sequence.
* You are free to use any format you like for the web API service (we have examples in JSON, but you can also use XML, or anything you like).
* The incubator can only be run after the settings have been provided.

## Deliverables

* The source code, any test data, and tests.
* Instructions on how to run your solution, including any dependencies which could be required.
* Documentation including any assumptions, things which were omitted by your solution, why you chose the technology you used, and what you could do to improve your solution.

## Time to complete task

We recognise that you are busy, have other commitments, and might be also applying for other roles. We would like you to spend no more than 3 hours on this challenge. We ask that you return this challenge in 7 days.
